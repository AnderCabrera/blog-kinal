# To run the project

```bash
npm i
```
```bash
npm run start
```

**Javascript aspects**

* use localStorage to store the data
* render all items from localStorage with JS
* it can add, update, delete, and mark as done the items
* it can filter the todo items by all, completed, uncompleted and the search bar