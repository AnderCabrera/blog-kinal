export const contactsTable = document.getElementById('contacts-table');

// export let contacts = JSON.parse(localStorage.getItem('contacts'));

// navbar
export const addContactModal = document.getElementById('add-contact-modal');

// modal update form
export const updateModal = document.getElementById('update-modal');
export const nameModal = document.getElementById('update-name');
export const lastnameModal = document.getElementById('update-lastname');
export const phoneModal = document.getElementById('update-phone');
export const emailModal = document.getElementById('update-email');
export const favoriteModal = document.getElementById('update-favorite');
export const continueModal = document.getElementById('update-contact');
export const cancelModal = document.getElementById('cancel-update');
export const xCloseModal = document.getElementById('x-close-modal');

// modal add form
export const addModal = document.getElementById('add-modal');
export const nameAddModal = document.getElementById('add-name');
export const lastnameAddModal = document.getElementById('add-lastname');
export const phoneAddModal = document.getElementById('add-phone');
export const emailAddModal = document.getElementById('add-email');
export const favoriteAddModal = document.getElementById('add-favorite');
export const addContactButton = document.getElementById('add-contact');
export const cancelAddButton = document.getElementById('cancel-add');
export const xCloseAddModal = document.getElementById('x-close-add-modal');