export const CONTACTS = 'contacts';
export const TODO = 'todo';
