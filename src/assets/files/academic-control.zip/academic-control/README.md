# Overview

This project do all wathever is suposed to do


## How to run the project?

```bash
  npm i
```

```
  npm run dev
```

> This are the credentials to generate your token as a TEACHER

| username | password |
|----------|----------|
| jnoj     | admin    |


Remember set your variables creating your .env file
The variables you should create are:

* PORT
* JWT_SECRET